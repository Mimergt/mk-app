<?php

namespace App\Filament\Resources\GasolineraResource\Pages;

use App\Filament\Resources\GasolineraResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateGasolinera extends CreateRecord
{
    protected static string $resource = GasolineraResource::class;
}

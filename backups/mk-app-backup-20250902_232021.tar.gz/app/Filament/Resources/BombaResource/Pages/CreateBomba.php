<?php

namespace App\Filament\Resources\BombaResource\Pages;

use App\Filament\Resources\BombaResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateBomba extends CreateRecord
{
    protected static string $resource = BombaResource::class;
}
